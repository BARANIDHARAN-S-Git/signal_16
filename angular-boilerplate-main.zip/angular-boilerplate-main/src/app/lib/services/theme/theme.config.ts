export type AppTheme = 'system' | 'light' | 'dark';
